Group JJSR CIS 550 Project- Movie Trivia

Node.js (NPM) Modules used are listed in 550/package.json

The main modules we used were Express.js (module name: "ejs"), Postgres (module name: "pg"), and Mongo (module names: "mongodb" and "mongoose"). We also used the BCrypt module to encrypt passwords (module name: "bcrypt-nodejs").

Setup should be easy. Just go to the 550 folder and run "node app.js" on your terminal. You should then be able to see the app running on localhost:8080.
Alternatively, you could also visit jjsr.herokuapp.com (this is where our app is hosted online).

Extra credit implemented and other details, including technical specifications are discussed in our project writeup.

Thank you!

Link to our github: https://github.com/sprihabaruah/DatabasesProject_JJSR