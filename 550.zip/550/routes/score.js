app.get('/score', function(req, res, next) {
	res.render('score');

	  // sending a response does not pause the function
	});
