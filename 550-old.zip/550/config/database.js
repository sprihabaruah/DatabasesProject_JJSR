// config/database.js
module.exports = {

    'url' : 'mongodb://JJSR:1234@apollo.modulusmongo.net:27017/waMe7mod' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    	

};